#Read Data
install.packages("readxl")
library("readxl")
inputData = read_excel(file.choose())
head(inputData)
table(inputData$Attrition)

#Training & Testing Set
dt = sort(sample(nrow(inputData), nrow(inputData)*.7))
trainData=inputData[dt,]
testData<-inputData[-dt,]
table(trainData$Attrition)
View(trainData)
colnames(trainData)

#Get INformation value of variables
install.packages("smbinning")
library(smbinning)
factor_vars <- c("BusinessTravel","Department","Education","EducationField","EnvironmentSatisfaction","Gender","JobInvolvement","JobLevel","JobRole","JobSatisfaction","MaritalStatus","OverTime","PerformanceRating","RelationshipSatisfaction","StockOptionLevel","TrainingTimesLastYear","WorkLifeBalance")
continuous_vars <- c("Age","DailyRate","DistanceFromHome","HourlyRate","MonthlyIncome","MonthlyRate","NumCompaniesWorked","PercentSalaryHike","PerformanceRating","StandardHours","TotalWorkingYears","YearsAtCompany","YearsInCurrentRole","YearsSinceLastPromotion","YearsWithCurrManager")
iv_df <- data.frame(VARS=c(factor_vars, continuous_vars), IV=numeric(32)) 

for(factor_var in factor_vars){
  smb <- smbinning.factor(trainData, y="Attrition", x=factor_var)  # WOE table
  if(class(smb) != "character"){ # heck if some error occured
    iv_df[iv_df$VARS == factor_var, "IV"] <- smb$iv
  }
}

for(continuous_var in continuous_vars){
  smb <- smbinning(trainData, y="Attrition", x=continuous_var)  # WOE table
  if(class(smb) != "character"){  # any error while calculating scores.
    iv_df[iv_df$VARS == continuous_var, "IV"] <- smb$iv
  }
}

iv_df <- iv_df[order(-iv_df$IV), ] 
iv_df

#Model
install.packages("MASS")
library(MASS)
logitMod <- glm(Attrition2 ~ BusinessTravel+Department+Education+EducationField+EnvironmentSatisfaction+Gender+JobInvolvement+JobLevel+JobRole+JobSatisfaction+MaritalStatus+OverTime+PerformanceRating+RelationshipSatisfaction+StockOptionLevel+TrainingTimesLastYear+WorkLifeBalance+Age+DailyRate+DistanceFromHome+HourlyRate+MonthlyIncome+MonthlyRate+NumCompaniesWorked+PercentSalaryHike+PerformanceRating+StandardHours+TotalWorkingYears+YearsAtCompany+YearsInCurrentRole+YearsSinceLastPromotion+YearsWithCurrManager, data=trainData, family=binomial(link="logit"))
logitMod
cor(trainData)
install.packages("Hmisc")
library(Hmisc)
rcorr(trainData)
head(trainData)
install.packages("polycor")
library(polycor)
hetcor(trainData)
summary(logitMod)
install.packages("car")
library(car)
vif(logitMod)
alias(logitMod)

logitMod <- glm(Attrition2 ~ BusinessTravel+Education+EducationField+EnvironmentSatisfaction+Gender+JobInvolvement+JobSatisfaction+MaritalStatus+OverTime+PerformanceRating+RelationshipSatisfaction+StockOptionLevel+TrainingTimesLastYear+WorkLifeBalance+Age+DailyRate+DistanceFromHome+HourlyRate+MonthlyIncome+MonthlyRate+NumCompaniesWorked+PercentSalaryHike+PerformanceRating+TotalWorkingYears+YearsInCurrentRole+YearsSinceLastPromotion+YearsWithCurrManager, data=trainData, family=binomial(link="logit"))
summary(logitMod)
vif(logitMod)

#Predict

predicted <- plogis(predict(logitMod, testData)) 
predicted
install.packages("InformationValue")
library(InformationValue)
misClassError(testData$Attrition2, predicted)

install.packages("caret")
library(caret)
confusionMatrix(testData$Attrition2, predicted)

install.packages("plotROC")
library(plotROC)
plotROC(testData$Attrition2, predicted)



logitMod2 <- glm(Attrition2 ~ BusinessTravel+OverTime+DistanceFromHome+MonthlyIncome+TotalWorkingYears, data=trainData, family=binomial(link="logit"))
summary(logitMod2)
predicted2 <- plogis(predict(logitMod2, testData))
plotROC(testData$Attrition2, predicted2)
misClassError(testData$Attrition2, predicted2)
confusionMatrix(testData$Attrition2, predicted2)


head(predicted2)

logitMod3 <- glm(Attrition2 ~ BusinessTravel+DistanceFromHome+Gender+JobRole+OverTime+TotalWorkingYears, data=trainData, family=binomial(link="logit"))
summary(logitMod3)
vif(logitMod3)
predicted3 <- plogis(predict(logitMod3, testData))
plotROC(testData$Attrition2,predicted3)
misClassError(testData$Attrition2, predicted3)
confusionMatrix(testData$Attrition2, predicted3)

inputData2 = read_excel(file.choose())
head(inputData2)
predict(logitMod3,inputData2)





head(testData)
